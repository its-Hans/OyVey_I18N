package it.make.api.i18n;

import it.make.Client;
import it.make.modules.Module;
import it.make.api.setting.Setting;
import it.make.modules.client.ClickGui;

public class I18NSetting extends Module {
    public I18NSetting() {
        super(new I18NInfo("I18NSetting").bind(EnumI18N.Chinese, "\u56fd\u9645\u5316"), "", Category.CLIENT);
    }

    Setting<EnumI18N> I18N = rother("I18N", EnumI18N.DEFAULT);
    Setting<Boolean> reloadClickGui = rbool("ReloadClickGui", true);

    @Override
    public void onEnable() {
        refresh();
        this.disable();
    }

    @Override
    public void onLoad() {
        refresh();
    }

    public void refresh() {
        Client.i18NManager.current=this.I18N.getValue();
        Client.moduleManager.refreshI18N();
        if (reloadClickGui.getValue()) ClickGui.getInstance().refreshGui();
    }
}
