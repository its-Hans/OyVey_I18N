package it.make.api.i18n;

import java.util.Map;
import java.util.TreeMap;

public class I18NInfo {
    public final String defaultName;
    public final Map<EnumI18N, String> i18ns;
    public I18NInfo(String defaultName) {
        this.defaultName = defaultName;
        this.i18ns = new TreeMap<>();
        this.i18ns.put(EnumI18N.DEFAULT, defaultName);
    }

    public I18NInfo bind(EnumI18N type, String i18n) {
        this.i18ns.put(type, i18n);
        return this;
    }

    public String getI18N(EnumI18N ENUMI18N) {
        if (i18ns.containsKey(ENUMI18N)) return i18ns.get(ENUMI18N);
        return this.defaultName;
    }
}
