package it.make.api.i18n;

public enum EnumI18N {
    English("EN"),
    Chinese("CN");
    public final String name;
    EnumI18N(String name) {
        this.name = name;
    }

    public static final EnumI18N DEFAULT = English;
}
